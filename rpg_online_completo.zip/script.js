// Config Firebase
const firebaseConfig = {
  apiKey: "SUA_API_KEY",
  authDomain: "SEU_DOMINIO.firebaseapp.com",
  projectId: "SEU_PROJECT_ID",
  storageBucket: "SEU_BUCKET.appspot.com",
  messagingSenderId: "SEU_SENDER_ID",
  appId: "SEU_APP_ID"
};

firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();

const loginContainer = document.getElementById('login-container');
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

function login() {
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  auth.signInWithEmailAndPassword(email, password)
    .then(user => startGame(user.user))
    .catch(error => showMessage(error.message));
}

function register() {
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  auth.createUserWithEmailAndPassword(email, password)
    .then(user => {
      db.collection('players').doc(user.user.uid).set({
        x: 50, y: 50, size: 32,
        hp: 100, maxHp: 100,
        inventory: []
      });
      startGame(user.user);
    })
    .catch(error => showMessage(error.message));
}

function showMessage(msg) {
  document.getElementById('message').innerText = msg;
}

function startGame(user) {
  loginContainer.style.display = 'none';
  canvas.style.display = 'block';

  let player = { x: 50, y: 50, size: 32, hp: 100, maxHp: 100, inventory: [] };
  const enemies = [
    { x: 300, y: 200, size: 32, hp: 50 }
  ];

  db.collection('players').doc(user.uid).get().then(doc => {
    if (doc.exists) player = doc.data();
  });

  const keys = {};
  window.addEventListener('keydown', e => keys[e.key] = true);
  window.addEventListener('keyup', e => keys[e.key] = false);

  function update() {
    if (keys['ArrowUp']) player.y -= 2;
    if (keys['ArrowDown']) player.y += 2;
    if (keys['ArrowLeft']) player.x -= 2;
    if (keys['ArrowRight']) player.x += 2;

    enemies.forEach(enemy => {
      if (Math.abs(enemy.x - player.x) < 50 && Math.abs(enemy.y - player.y) < 50) {
        // Combat!
        if (keys[' ']) {
          enemy.hp -= 10;
        }
        if (Math.random() < 0.01) {
          player.hp -= 5;
        }
      }
    });

    // Pick up item (mock)
    if (keys['e']) {
      if (!player.inventory.includes('Poção')) {
        player.inventory.push('Poção');
      }
    }

    // Use item
    if (keys['1'] && player.inventory.includes('Poção')) {
      player.hp = Math.min(player.hp + 30, player.maxHp);
      player.inventory = player.inventory.filter(i => i !== 'Poção');
    }
  }

  function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#e94560';
    ctx.fillRect(player.x, player.y, player.size, player.size);

    enemies.forEach(enemy => {
      if (enemy.hp > 0) {
        ctx.fillStyle = 'green';
        ctx.fillRect(enemy.x, enemy.y, enemy.size, enemy.size);
      }
    });

    // UI
    ctx.fillStyle = 'white';
    ctx.fillText(`HP: ${player.hp}/${player.maxHp}`, 10, 20);
    ctx.fillText(`Inventário: ${player.inventory.join(', ')}`, 10, 40);
  }

  function loop() {
    update();
    draw();
    db.collection('players').doc(user.uid).set(player);
    requestAnimationFrame(loop);
  }

  loop();
}